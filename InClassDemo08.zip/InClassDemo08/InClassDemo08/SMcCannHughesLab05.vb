﻿Option Strict On
Imports System.IO

Public Class SMcCannHughesLab05
    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click

        Dim result As Integer = MessageBox.Show("Have You Saved Your Document?", "Warning", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            txtContent.Clear()

        ElseIf CBool(DialogResult.No) Then
            MessageBox.Show("Please Save Document")
        End If



    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click

        Application.Exit()

    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click

        If ofdOpenFileDialogue.ShowDialog() = DialogResult.OK Then

            Try

                Dim reader As New StreamReader(ofdOpenFileDialogue.FileName)
                txtContent.Text = reader.ReadToEnd
                reader.Close()

            Catch ex As Exception

                Throw New ApplicationException(ex.ToString())

            End Try

        End If

    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click

        sfdSaveFileDialogue.Filter = "TXT Files (*.txt*)|*.txt"

        If sfdSaveFileDialogue.ShowDialog() = DialogResult.OK Then

            My.Computer.FileSystem.WriteAllText(sfdSaveFileDialogue.FileName, txtContent.Text, False)

        End If

    End Sub
    Private Sub SaveAsToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem1.Click

        Dim sfd As New SaveFileDialog()
        sfd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        sfd.FilterIndex = 1
        sfd.RestoreDirectory = True
        If sfd.ShowDialog() = DialogResult.OK Then
            Dim FileName As String = sfd.FileName
            Dim sw As New System.IO.StreamWriter(FileName, False)
            sw.WriteLine(txtContent.Text)
            sw.Close()
        End If

    End Sub

    Private Sub NewCtrlNToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewCtrlNToolStripMenuItem.Click

        Dim result As Integer = MessageBox.Show("Have You Saved Your Document?", "Warning", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            txtContent.Clear()
            MessageBox.Show("New Document Created")
        ElseIf CBool(DialogResult.No) Then
            MessageBox.Show("Please Save Document")
        End If

    End Sub

    Private Sub CopyCtrlCToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyCtrlCToolStripMenuItem.Click

        Clipboard.SetText(txtContent.SelectedText)

    End Sub

    Private Sub CutCtrlXToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutCtrlXToolStripMenuItem.Click

        Clipboard.SetText(txtContent.SelectedText)
        txtContent.SelectedText = ""

    End Sub

    Private Sub PasteCtrlVToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteCtrlVToolStripMenuItem.Click

        txtContent.SelectedText = Clipboard.GetText

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click

        MsgBox("Author: Sarah McCann-Hughes" + vbCrLf + "Class: NetD 2202" + vbCrLf + "Lab: #5", MsgBoxStyle.OkOnly, "About")


    End Sub
End Class